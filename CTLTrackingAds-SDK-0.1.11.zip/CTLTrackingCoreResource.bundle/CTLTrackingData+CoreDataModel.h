//
//  CTLTrackingData+CoreDataModel.h
//  
//
//  Created by Thai Linh on 7/16/19.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

#import "Tracking+CoreDataClass.h"




